from django.apps import AppConfig


class AnsibleRunConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ansible_run'
